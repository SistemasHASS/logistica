
export interface TareoIncidencia {
  id: number;
  iddocumento: string;
  ruc: string;
  tipodocumento: string;
  descripcion: string;
  estado: number;
}