export interface Almacen {
  id: number;
  idalmacen: string;
  almacen?: string;
}
